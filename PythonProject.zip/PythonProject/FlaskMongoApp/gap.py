import os
import bcrypt
from flask import Flask, request, session, jsonify, render_template_string
from pymongo import MongoClient

app = Flask(__name__)
app.secret_key = os.urandom(24)

# MongoDB Configuration
client = MongoClient("mongodb://localhost:27017/")
db = client.contact_db

# HTML Template
html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Flask Mongo Contact App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { background-color: #f4f4f4; color: #333; font-family: Arial, sans-serif; }
        .container { max-width: 600px; margin-top: 50px; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); }
        .hidden { display: none; }
        .btn { width: 100%; margin-top: 10px; }
        .sidebar { width: 220px; height: 100vh; position: fixed; background-color: #333; color: white; padding: 20px; }
        .sidebar a { display: block; color: white; padding: 10px; text-decoration: none; margin-bottom: 5px; border-radius: 5px; }
        .sidebar a:hover { background-color: #0078D7; }
        .main-content { margin-left: 240px; padding: 20px; }
    </style>
</head>
<body>

<div class="container" id="authPage">
    <h2 class="text-center">Login</h2>
    <input type="text" id="authUsername" placeholder="Username" class="form-control">
    <input type="password" id="authPassword" placeholder="Password" class="form-control">
    <button onclick="login()" class="btn btn-primary">Login</button>
    <button onclick="register()" class="btn btn-secondary">Register</button>
</div>

<div class="hidden" id="appContent">
    <div class="sidebar">
        <h3>Dashboard</h3>
        <a href="#" onclick="showPage('addContactPage')">➕ Add Contact</a>
        <a href="#" onclick="showPage('searchContactPage')">🔍 Search Contact</a>
        <a href="#" onclick="logout()">🚪 Logout</a>
    </div>
    <div class="main-content">
        <div class="container hidden" id="addContactPage">
            <h3>Add Contact</h3>
            <input type="text" id="regNo" placeholder="Registration Number" class="form-control">
            <input type="text" id="mobile" placeholder="Mobile Phone" class="form-control">
            <input type="email" id="email" placeholder="Email" class="form-control">
            <input type="text" id="address" placeholder="Address" class="form-control">
            <button onclick="addContact()" class="btn btn-success">Save Contact</button>
        </div>
        <div class="container hidden" id="searchContactPage">
            <h3>Search Contact</h3>
            <input type="text" id="searchRegNo" placeholder="Enter Registration Number" class="form-control">
            <button onclick="searchContact()" class="btn btn-secondary">Search</button>
            <button onclick="clearSearchResults()" class="btn btn-warning">Done</button>
            <div id="searchResult" class="mt-3"></div>
        </div>
    </div>
</div>

<script>
function showPage(pageId) {
    document.querySelectorAll('.container').forEach(div => div.classList.add('hidden'));
    document.getElementById(pageId).classList.remove('hidden');
}

function login() {
    fetch('/login', {
        method: 'POST',
        body: JSON.stringify({
            username: document.getElementById("authUsername").value,
            password: document.getElementById("authPassword").value
        }),
        headers: { 'Content-Type': 'application/json' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            document.getElementById("authPage").classList.add('hidden');
            document.getElementById("appContent").classList.remove('hidden');
        } else {
            Swal.fire("Error", data.message, "error");
        }
    });
}

function register() {
    fetch('/register', {
        method: 'POST',
        body: JSON.stringify({
            username: document.getElementById("authUsername").value,
            password: document.getElementById("authPassword").value
        }),
        headers: { 'Content-Type': 'application/json' }
    })
    .then(res => res.json())
    .then(data => Swal.fire("Info", data.message, data.success ? "success" : "error"));
}

function addContact() {
    let formData = new FormData();
    formData.append("registration_number", document.getElementById("regNo").value);
    formData.append("mobile", document.getElementById("mobile").value);
    formData.append("email", document.getElementById("email").value);
    formData.append("address", document.getElementById("address").value);

    fetch('/add_contact', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        Swal.fire("Success", data.message, "success");
        document.querySelectorAll("#addContactPage input").forEach(input => input.value = '');
    });
}

function searchContact() {
    fetch('/search_contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ registration_number: document.getElementById("searchRegNo").value })
    })
    .then(res => res.json())
    .then(data => {
        if (!data.success) Swal.fire("Error", "Contact Not Found", "error");
        else document.getElementById("searchResult").innerHTML = JSON.stringify(data.contact, null, 2);
    });
}

function clearSearchResults() {
    document.getElementById("searchResult").innerHTML = "";
}
</script>

</body>
</html>
"""


@app.route('/')
def home():
    return render_template_string(html_template)


@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    if db.users.find_one({'username': data['username']}):
        return jsonify({'success': False, 'message': 'Username already exists'})

    hashed_pw = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt())
    db.users.insert_one({'username': data['username'], 'password': hashed_pw})

    return jsonify({'success': True, 'message': 'Registration successful! You can now log in.'})


@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = db.users.find_one({'username': data['username']})

    if user and bcrypt.checkpw(data['password'].encode('utf-8'), user['password']):
        session['username'] = data['username']
        return jsonify({'success': True})

    return jsonify({'success': False, 'message': 'Invalid credentials'})


@app.route('/logout')
def logout():
    session.clear()
    return jsonify({'success': True})


@app.route('/add_contact', methods=['POST'])
def add_contact():
    db.contacts.insert_one(request.form.to_dict())
    return jsonify({'success': True, 'message': 'Contact saved successfully!'})


@app.route('/search_contact', methods=['POST'])
def search_contact():
    contact = db.contacts.find_one({"registration_number": request.json.get("registration_number")}, {'_id': 0})
    return jsonify({'success': bool(contact), 'contact': contact or 'Contact Not Found'})


if __name__ == '__main__':
    app.run(debug=True)